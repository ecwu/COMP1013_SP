#include<stdio.h>
int main(){
	printf("hello World\nHello World\nHello World\n");
	return 0;
}